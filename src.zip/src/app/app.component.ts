import { Component, TemplateRef } from '@angular/core';
import { ToastrManager } from 'ng6-toastr-notifications';
import { NgxSpinnerService } from 'ngx-spinner';
import { _ } from 'underscore';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'BBC';
  GridData = [{"id":1,"PlayerName":"Virat Kohli","Role":"Batsman (Captain)"},
              {"id":2,"PlayerName":"Mithali Rajr","Role":"Batsman (Captain)"},
              {"id":3,"PlayerName":"Harmanpreet Kaur","Role":"All-Rounder"},
              {"id":4,"PlayerName":"Ajinkya Rahane","Role":"Batsman "},
              {"id":5,"PlayerName":"MS Dhoni","Role":"Wicketkeeper-Batsman "},
              {"id":6,"PlayerName":"Lokesh Rahul","Role":"Batsman "},
              {"id":7,"PlayerName":"Manish Pandey","Role":"Batsman "},
              {"id":8,"PlayerName":"Kedar Jadhav","Role":"Batsman "},
            ]
            model = {"id":"","PlayerName":"","Role":	""}
            PlayerName = "";
            Role = "";
            Id = "0";
            lengthOfGrid = this.GridData.length;
            constructor(public toastr: ToastrManager,private spinner: NgxSpinnerService) {}
           ngOnInit(){
            this.spinner.show();
 
            setTimeout(() => {
                /** spinner ends after 5 seconds */
                this.spinner.hide();
            }, 1000);
           }
           
            openDialog(idsearch): void {
              document.getElementById('id01').style.display='block';
               this.model = _.where(this.GridData, {id: idsearch});
               this.PlayerName = this.model[0].PlayerName;
               this.Role = this.model[0].Role;
               this.Id = this.model[0].id;

              }
              AddPlayer(idToAdd): void {
                document.getElementById('id01').style.display='block';
                
                 this.PlayerName = "";
                 this.Role = "";
                 this.Id = idToAdd;
  
                }

              Remove(ID):void{
                this.GridData = this.GridData.filter(item => item.id !== ID);
                this.toastr.infoToastr('Player removed from club.', 'Info',{position:'bottom-right'});
              }
              SaveData(saveid): void {
                if(this.PlayerName != ""){
               if(saveid != "0"){
                this.GridData.forEach(element => {
                   if(element.id == saveid){
                     element.PlayerName = this.PlayerName;
                     element.Role = this.Role;
                   }
                 });
                 this.toastr.successToastr('Changes been saved.', 'Success!',{position:'bottom-right'});
               }
               else{
                 var neData = {"id":this.lengthOfGrid+1,"PlayerName":this.PlayerName,"Role":this.Role};
                 this.GridData.push(neData);
                 this.toastr.successToastr('New Player Added to club.', 'Success!',{position:'bottom-right'});
               }
               document.getElementById('id01').style.display='none'
              }
              
              }
}
